

<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('styles'); ?>
  <!-- DataTables -->
  <link href="<?php echo e(asset('dashboard_assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(asset('dashboard_assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
  
  <!-- Responsive datatable examples -->
  <link href="<?php echo e(asset('dashboard_assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
  <?php if(\session()->has('message')): ?>
    <?php echo \session()->get('message'); ?>

  <?php endif; ?>
  <div class="page-content">
    <div class="container-fluid">
      
      <!-- start page title -->
      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0 font-size-18"><?php echo e($title); ?></h4>
          
          
          
          </div>
        </div>
      </div>
      <!-- end page title -->
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              
              <h4 class="header-title"><?php echo e($title); ?></h4>
              <p>List Data Kucing yang sudah ditambahkan</p>
              <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Foto</th>
                    <th class="text-center">Di Apdopsi Pada</th>
                    <th class="text-center">Dibuat</th>
                    <th class="text-center">Aksi</th>
                  </tr>
                </thead>
                
                
                <tbody>
                
                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td data-order="<?php echo e($cat->id); ?>"><?php echo e($cat->id); ?></td>
                    <td>
                      <?php echo e($cat->name); ?>

                    </td>
                    <td class="text-center">
                      <?php if($cat->status == 'off'): ?>
                        <span class="badge badge-secondary">Close Adopt</span>
                      <?php elseif($cat->status == 'waiting'): ?>
                        <span class="badge badge-warning">Menunggu Adopter</span>
                      <?php else: ?>
                        <span class="badge badge-primary">Adopted</span>
                      <?php endif; ?>
                    </td>
                    <td class="text-center">
                      <a href="<?php echo e(Storage::url($cat->image)); ?>" target="_blank">Lihat</a>
                    </td>
                    <td class="text-center">
                      <?php if(!empty($cat->adopted_at)): ?>
                        <span data-toggle="tooltip" data-placement="top" title="<?php echo e(\Carbon\Carbon::parse($cat->adpoted_at)->diffForHumans()); ?>">
                          <?php echo e(\Carbon\Carbon::parse($cat->adpoted_at)->format('d-m-Y H:i')); ?>

                        </span>
                      <?php else: ?>
                        -
                      <?php endif; ?>
                    </td>
                    <td class="text-center">
                      <span data-toggle="tooltip" data-placement="top" title="<?php echo e(\Carbon\Carbon::parse($cat->created_at)->diffForHumans()); ?>">
                        <?php echo e(\Carbon\Carbon::parse($cat->created_at)->format('d-m-Y H:i')); ?>

                      </span>
                    </td>
                    <td class="text-center">
                      <div class="btn-group btn-group-sm mt-1 mr-1 dropright" style="z-index: 999999;">
                        <button type="button" class="btn btn-secondary waves-effect waves-light dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="mdi mdi-chevron-down"></i> Pilihan
                        </button>
                        <div class="dropdown-menu">
                          <a class="dropdown-item" href="<?php echo e(route('dashboard.cat.edit',['cat' => $cat->id])); ?>">Detail Data Kucing</a>
                          <div class="dropdown-divider"></div>
                          <a class="dropdown-item btn_delete" data-nama="<?php echo e($cat->name); ?>"
                             data-href="<?php echo e(route('dashboard.cat.destroy', ['cat' => $cat->id])); ?>"
                             href="javascript:0;">Hapus Data Kucing</a>
                        </div>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            
            </div>
          </div>
        </div> <!-- end col -->
      </div> <!-- end row -->
      <!-- end row -->
      
      <!-- end row -->
    
    </div> <!-- container-fluid -->
  </div>
  <!-- End Page-content -->
  <form class="form_delete" action="" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
  </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <!-- Required datatable js -->
  <script src="<?php echo e(asset('dashboard_assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboard_assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
  <!-- Responsive examples -->
  <script src="<?php echo e(asset('dashboard_assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboard_assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>
  
  <script>
      $(document).ready(function (){
          // let table = $('#datatable').DataTable()
          let table = $('#datatable')

          let t = table.DataTable({
              'order': [ 0, 'desc' ]
          })

          let nama = '';
          table.on('click', '.btn_delete', function (e){
              nama = $(this).data('nama')
              e.preventDefault();
              Swal.fire({
                  title: 'Anda Yakin?',
                  text: 'Hapus Data Kucing ' + nama + ' ?',
                  icon: 'question',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Ya, lanjutkan!',
                  cancelButtonText: 'Batal'
              }).then((result) => {
                  if (result.isConfirmed) {
                      Swal.fire({
                          title: 'Pertanyaan Terakhir!',
                          text: 'Tidak bisa diulangi!',
                          icon: 'warning',
                          showCancelButton: true,
                          confirmButtonColor: '#3085d6',
                          cancelButtonColor: '#d33',
                          confirmButtonText: 'Ya, hapus data kucing!',
                          cancelButtonText: 'Batal'
                      }).then((result) => {
                          if (result.isConfirmed) {
                              $('.form_delete').attr('action', $(this).data('href')).submit()
                          }
                      })
                  }
              })
          })
      })
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.v_main_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cat-adopt\resources\views/admin/cat/index.blade.php ENDPATH**/ ?>