<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="shortcut icon" href="<?php echo e(asset('home_assets/images/favicon.ico')); ?>">

    <title><?php echo e($title); ?> | <?php echo e(getenv('APP_NAME')); ?></title>
  
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  
    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('home_assets/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- tiny slider -->
    <link href="<?php echo e(asset('home_assets/css/tiny-slider.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('home_assets/css/swiper.min.css')); ?>" type="text/css" />


    <!-- Materialdesign icons css -->
    <link href="<?php echo e(asset('home_assets/css/materialdesignicons.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('home_assets/css/style.css')); ?>" rel="stylesheet">
    
    <?php echo $__env->yieldContent('css'); ?>
  
</head>

<body data-bs-spy="scroll" data-bs-target="#navbar-navlist" data-bs-offset="71">

    <!--Navbar Start-->
    <?php echo $__env->make('layouts.home.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Navbar End -->

    <?php echo $__env->yieldContent('content'); ?>
    
    <!-- start footer -->
    <?php echo $__env->make('layouts.home.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end footer -->

    <!-- bootstrap -->
    <script src="<?php echo e(asset('home_assets/js/bootstrap.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(asset('home_assets/js/tiny-slider.js')); ?>"></script>
    <script src="<?php echo e(asset('home_assets/js/swiper.min.js')); ?>"></script>

    <!-- counter -->
    <script src="<?php echo e(asset('home_assets/js/counter.init.js')); ?>"></script>

    <!-- Custom -->
    <script src="<?php echo e(asset('home_assets/js/app.js')); ?>"></script>
    
    <?php echo $__env->yieldContent('js'); ?>

</body>

</html><?php /**PATH C:\laragon\www\cat-adopt\resources\views/layouts/home/v_main_home.blade.php ENDPATH**/ ?>