<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <?php if(\session()->has('message')): ?>
        <?php echo \session()->get('message'); ?>

    <?php endif; ?>
    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0 font-size-18"><?php echo e($title); ?></h4>



                    </div>
                </div>
            </div>
            <!-- end page title -->
          <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.v_main_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cat-adopt\resources\views/admin/v_admin_index.blade.php ENDPATH**/ ?>