



















































<div class="bg-white mt-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-10">
        <div class="copy-right mb-5 text-center text-muted">
          <script>document.write(new Date().getFullYear())</script> <?php echo e(getenv('APP_NAME')); ?>. Design with <i
            class="mdi mdi-heart-box text-danger"></i> by <a
            href="<?php echo e(url('')); ?>" target="_blank"
            class="text-reset"><?php echo e(getenv('APP_NAME')); ?></a>.
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\laragon\www\cat-adopt\resources\views/layouts/home/partials/footer.blade.php ENDPATH**/ ?>