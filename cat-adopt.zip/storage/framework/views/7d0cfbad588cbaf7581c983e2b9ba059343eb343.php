<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <?php echo e(date('Y')); ?> © <?php echo e(getenv('APP_NAME')); ?>.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-right d-none d-sm-block">
                    Crafted with <i class="mdi mdi-heart text-danger"></i> by <?php echo e(getenv('APP_NAME')); ?>

                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\cat-adopt\resources\views/layouts/admin/partials/footer.blade.php ENDPATH**/ ?>