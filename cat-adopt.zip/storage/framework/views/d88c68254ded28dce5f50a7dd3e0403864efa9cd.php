<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> - Admin</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesdesign" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('home_assets/images/favicon.ico')); ?>">

    <!-- Bootstrap Css -->
    <link href="<?php echo e(asset('dashboard_assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="<?php echo e(asset('dashboard_assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="<?php echo e(asset('dashboard_assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" />

    <script src="<?php echo e(asset('js/sweet-alert.js')); ?>"></script>

    <?php echo $__env->yieldContent('styles'); ?>

</head>

<body data-topbar="colored" >

<!-- Begin page -->
<div id="layout-wrapper">

<?php echo $__env->make('layouts.admin.partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <div class="main-content">

        <?php echo $__env->yieldContent('contents'); ?>

        <?php echo $__env->make('layouts.admin.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- end main content-->

</div>
<!-- END layout-wrapper -->

<?php echo $__env->make('layouts.admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- JAVASCRIPT -->
<script src="<?php echo e(asset('dashboard_assets/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard_assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard_assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard_assets/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard_assets/libs/node-waves/waves.min.js')); ?>"></script>

<script src="<?php echo e(asset('dashboard_assets/js/app.js')); ?>"></script>

<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\cat-adopt\resources\views/layouts/admin/v_main_admin.blade.php ENDPATH**/ ?>