{{--<section class="footer py-5 bg-white">--}}
{{--  <div class="container">--}}
{{--    <div class="row">--}}
{{--      <div class="col-lg-6">--}}
{{--        <div class="address-content fw-bold">--}}
{{--          <h5 class="text-black">Address</h5>--}}
{{--          <p class="mt-5  f-14 ">River Way behind Salt Lake City, UT 8402</p>--}}
{{--          <p class="mt-3 f-14 ">+(540)801-468-2313 (10am - 6pm, Monday - Saturday)</p>--}}
{{--          <a href="" class=" f-14">info@example.com</a>--}}
{{--        </div>--}}
{{--        <div class="social-icon d-flex mt-4 mb-4 mb-lg-0">--}}
{{--          <div class="facebook">--}}
{{--            <a href=""><i class="mdi mdi-facebook-box f-30"></i></a>--}}
{{--          </div>--}}
{{--          <div class="twitter ms-4">--}}
{{--            <a href=""><i class="mdi mdi-twitter f-30"></i></a>--}}
{{--          </div>--}}
{{--          <div class="twitter ms-4">--}}
{{--            <a href=""><i class="mdi mdi-instagram f-30"></i></a>--}}
{{--          </div>--}}
{{--          <div class="twitter ms-4">--}}
{{--            <a href=""><i class="mdi mdi-linkedin-box f-30"></i></a>--}}
{{--          </div>--}}
{{--        </div>--}}
{{--      </div>--}}
{{--      <div class="col-lg-4">--}}
{{--        <h5 class="text-black">Explore</h5>--}}
{{--        <ul class="menu list-unstyled mt-5">--}}
{{--          <li class="menu-item"><a href="">Start here</a></li>--}}
{{--          <li class="menu-item"><a href="">Services</a></li>--}}
{{--          <li class="menu-item"><a href="">Features</a></li>--}}
{{--          <li class="menu-item"><a href="">Client</a></li>--}}
{{--          <li class="menu-item"><a href="">Pricing</a></li>--}}
{{--          <li class="menu-item"><a href="">support center</a></li>--}}
{{--          <li class="menu-item"><a href="">Blogs</a></li>--}}
{{--          <li class="menu-item"><a href="">Newsletters</a></li>--}}
{{--        </ul>--}}
{{--      --}}
{{--      </div>--}}
{{--      <div class="col-lg-2">--}}
{{--        <h5 class="text-black">Explore</h5>--}}
{{--        <ul class="menu mt-5 list-unstyled d-block">--}}
{{--          <li class="info-item"><a href="">Membership</a></li>--}}
{{--          <li class="info-item"><a href="">Purchase guide</a></li>--}}
{{--          <li class="info-item"><a href="">Privacy policy</a></li>--}}
{{--          <li class="info-item"><a href="">Terms of service</a></li>--}}
{{--        </ul>--}}
{{--      </div>--}}
{{--    </div>--}}
{{--  </div>--}}
{{--</section>--}}

<div class="bg-white mt-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-10">
        <div class="copy-right mb-5 text-center text-muted">
          <script>document.write(new Date().getFullYear())</script> {{ getenv('APP_NAME') }}. Design with <i
            class="mdi mdi-heart-box text-danger"></i> by <a
            href="{{ url('') }}" target="_blank"
            class="text-reset">{{ getenv('APP_NAME') }}</a>.
        </div>
      </div>
    </div>
  </div>
</div>